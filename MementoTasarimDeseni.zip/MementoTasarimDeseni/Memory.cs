﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MementoPattern
{
    class Memory
    {
        public Memento ProductMemento { get; set; }
    }

    
}
